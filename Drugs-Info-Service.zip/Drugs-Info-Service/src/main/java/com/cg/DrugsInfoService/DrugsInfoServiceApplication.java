package com.cg.DrugsInfoService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrugsInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrugsInfoServiceApplication.class, args);
	}

}
