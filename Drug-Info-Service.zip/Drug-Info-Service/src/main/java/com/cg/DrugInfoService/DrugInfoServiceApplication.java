package com.cg.DrugInfoService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrugInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrugInfoServiceApplication.class, args);
	}

}
